# -*- coding: utf-8 -*-
# **************************************************************
# Object Query Language, for Gramps and others
#
# Copyright (c) Douglas Blank
# MIT License
#
# Largely based on https://github.com/DavidMStraub/gramps-ql
# **************************************************************

version_info = (0, 1, 2)
__version__ = ".".join(map(str, version_info))
