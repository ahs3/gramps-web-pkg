
.. include:: ../AUTHORS.rst
