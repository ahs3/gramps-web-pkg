
*******
License
*******

.. literalinclude:: ../LICENSE
