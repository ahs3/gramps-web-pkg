export default {
  files: 'test/**/*.test.js',
  nodeResolve: true
};