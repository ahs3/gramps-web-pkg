import {GrampsJs} from './GrampsJs.js'

customElements.define('gramps-js', GrampsJs)
