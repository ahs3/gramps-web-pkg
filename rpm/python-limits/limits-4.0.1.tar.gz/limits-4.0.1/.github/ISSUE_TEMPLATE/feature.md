---
name: Feature or Enhancement
about: Propose a new feature or enhancement
labels: 'enhancement'

---

<!--- Provide a general summary of the proposal in the Title above -->

## Expected Behaviour

<!--- How should this new feature work -->

<!--
You can freely edit this text. Remove any lines you believe are unnecessary.
-->

